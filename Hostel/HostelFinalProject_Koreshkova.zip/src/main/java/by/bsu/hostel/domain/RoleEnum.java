package by.bsu.hostel.domain;

/**
 * Created by Kate on 29.03.2016.
 */
public enum RoleEnum {
    USER,
    ADMIN;
}
